﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;

namespace _10_15
{
    class Car
    {
        

        string carName, carColor;
        
        public Car(string carName, string carColor)
        {
            this.carName = carName;
            this.carColor = carColor;
        }

        public void addCar()
        {
        }

        static void Main(string[] args)
        {
            string cont = "1";
            string custName, answer, n, clr;

            OleDbConnection conn = new OleDbConnection();
            conn.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\xdark\Documents\Reservations.accdb;
Persist Security Info=False;";



            
            Console.WriteLine("Welcome to this program, close the program to exit");
            while (cont != "-1")
            {
                Console.WriteLine("\nWhat is your name?");
                custName = Console.ReadLine();

                Console.WriteLine("Would you like to add, cancel, or pick up a reservation? add, cancel, pick up");
                answer = Console.ReadLine();

                if (answer.Equals("add"))
                {
                    Console.WriteLine("What car model would you like? cooper, mustang, ram");
                    n = Console.ReadLine();
                    Console.WriteLine("What car color would you like? red, blue, white");
                    clr = Console.ReadLine();

                    conn.Open();
                    OleDbCommand comm = new OleDbCommand();
                    comm.Connection = conn;
                    comm.CommandText = "INSERT INTO Reservations(CustName, CarName, CarColor)"
                                + "VALUES ('" + custName + "', '" + n
                                + "', '" + clr + "')";
                    comm.Parameters.AddWithValue("@CustName", custName);
                    comm.Parameters.AddWithValue("@CarName", n);
                    comm.Parameters.AddWithValue("@CarColor", clr);
                    comm.ExecuteNonQuery();
                    conn.Close();
                    Console.WriteLine("Your reservation is for " + custName 
                        + ". Your car is the " + clr + " " + n);
                }
                else if (answer.Equals("cancel"))
                {
                    conn.Open();
                    OleDbCommand comm = new OleDbCommand();
                    comm.Connection = conn;
                    comm.CommandText = "DELETE * FROM Reservations WHERE CustName= '"
                        + custName + "'";
                    comm.ExecuteNonQuery();
                    conn.Close();
                    Console.WriteLine("Your reservation for " + custName 
                        + " has been cancelled.");
                }
                else if (answer.Equals("pick up"))
                {
                    conn.Open();
                    OleDbCommand comm = new OleDbCommand();
                    comm.Connection = conn;
                    comm.CommandText = "SELECT CarName, CarColor FROM Reservations WHERE CustName= '"
                        + custName + "'";
                    OleDbDataReader reader = comm.ExecuteReader();
                    while (reader.Read())
                    {
                        n = (reader["CarName"].ToString());
                        clr = (reader["CarColor"].ToString());
                        Console.WriteLine("You picked up you your " + clr + " " + n);
                    }
                    conn.Close();
                }
            }
        }
    }
}
